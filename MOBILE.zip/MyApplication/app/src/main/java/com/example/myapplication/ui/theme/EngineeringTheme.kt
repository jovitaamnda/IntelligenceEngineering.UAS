package com.example.myapplication.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.runtime.Composable
import androidx.compose.material3.MaterialTheme

// Ganti warna dengan warna merek Anda.
private val EngineeringPurple80 = Color(0xFFD0BCFF)
private val EngineeringGrey80 = Color(0xFFCCC2DC)
private val EngineeringPink80 = Color(0xFFEFB8C8)

private val EngineeringPurple40 = Color(0xFF6650a4)
private val EngineeringPurpleGrey40 = Color(0xFF625b71)
private val EngineeringPink40 = Color(0xFF7D5260)

private val DarkColorScheme = darkColorScheme(
    primary = EngineeringPurple80,
    secondary = EngineeringGrey80,
    tertiary = EngineeringPink80
)

private val LightColorScheme = lightColorScheme(
    primary = EngineeringPurple40,
    secondary = EngineeringPurpleGrey40,
    tertiary = EngineeringPink40)

@Composable
fun EngineeringTheme(
    darkTheme: Boolean = isSystemInDarkTheme(),
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) {
        DarkColorScheme
    } else {
        LightColorScheme
    }

    // Inisialisasi Shapes di luar MaterialTheme
    val Shapes = Shapes(
        small = RoundedCornerShape(4.dp),
        medium = RoundedCornerShape(4.dp),
        large = RoundedCornerShape(0.dp)
    )

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography, // Gunakan tipografi Anda jika didefinisikan
        shapes = Shapes, // Gunakan bentuk Anda jika didefinisikan
        content = content
    )
}
