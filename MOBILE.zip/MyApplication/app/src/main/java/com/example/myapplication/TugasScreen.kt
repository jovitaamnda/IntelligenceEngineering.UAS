package com.example.myapplication

import androidx.compose.runtime.Composable
import androidx.compose.material3.Text
import androidx.compose.foundation.layout.Column
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.foundation.layout.padding
import androidx.navigation.compose.composable

@Composable
fun TugasScreen() {

}

@Composable
fun TugasScreenContent(fileUri: String?) {
    Column(modifier = Modifier.padding(16.dp)) {
        Text("Ini adalah layar Tugas")

        // Tampilkan file yang diunggah jika tersedia
        fileUri?.let {
            Text("File yang Diunggah: $it")
            // Tambahkan logika di sini untuk menampilkan file berdasarkan URI
            // Misalnya, jika itu adalah gambar, Anda dapat menggunakan Image Composable
        }
    }
}