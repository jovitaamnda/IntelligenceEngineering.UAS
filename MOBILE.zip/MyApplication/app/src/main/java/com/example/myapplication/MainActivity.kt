package com.example.myapplication

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.runtime.Composable
import androidx.compose.ui.tooling.preview.Preview
import com.example.myapplication.Navigation
import com.example.myapplication.ui.theme.EngineeringTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.navigation.compose.rememberNavController
import com.example.myapplication.ui.theme.MyApplicationTheme
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.navigation.NavController
import androidx.compose.material3.rememberDrawerState
import androidx.compose.material3.DrawerValue
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.material3.ModalNavigationDrawer
import androidx.navigation.NavHostController
import com.example.myapplication.Navigation
import androidx.compose.ui.graphics.Color
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.compose.material3.Button
import androidx.navigation.compose.composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.ui.unit.dp
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember






class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MyApplicationTheme {
                Surface(color = MaterialTheme.colorScheme.background) {
                    val navController = rememberNavController()
                    AppNavigation(navController) // Panggil Composable Navigation di sini
                }
            }
        }
    }

    @Preview(showBackground = true)
    @Composable
    fun DefaultPreview() {
        MyApplicationTheme {
            val navController = rememberNavController()
            val savedData = remember { mutableStateOf("") }
            val uploadedData = remember { mutableStateOf("") }
            Navigation(navController,savedData, uploadedData)
        }
    }
}

@Composable
fun MyScreen() {
    MaterialTheme {
        Text("Halo, ini menggunakan MaterialTheme!", color = MaterialTheme.colorScheme.primary)
    }
}

@Composable
fun AppNavigation(navController: NavHostController) {
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val savedData = remember { mutableStateOf("") }
    val uploadedData = remember { mutableStateOf("") }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            DrawerContent(navController, drawerState, scope)}
    ) {
        NavHost(navController = navController, startDestination = "start") {
            composable("start") { StartScreen(navController ) }
            composable("formulir") {
                Mainscreen(navController, onSubmitData = { newText ->
                    savedData.value = newText
                })
            }
            composable("Tugas") {TaskScreen(savedData.value, uploadedData.value, ) }
            // Tambahkan rute lain yang mungkin Anda perlukan di sini
        } // Tutup blok NavHost di sini
    }
}

@Composable
fun ShowSubmittedData(
    namaTugas: String, deskripsiMasalah: String, prioritasTugas: String,
    userOutcomes: String, leadingIndicator: String, manfaatProject: String,
    modelAi: String, statusTugas: String, analisisMasalah: String,
    tanggalMulai: String,  tanggalbataswaktu: String,  TanggalDibuat: String,  tanggalDiperbarui: String, NamaProyek: String, InformasiTugas: String,  IdProyek: String,
    PenanggungJawab: String,InformasiProyek : String,  TimPelaksana : String,  DetailAnalisis : String,  SumberData : String, TujuanAnalisis : String, MetodeAnalisis : String, AlatAnalisis : String, CatatanTambahan : String,
    currentSubmittedData: String,
    onUpdateSubmittedData: (String) -> Unit
) {
    // Perbarui submittedData di sini
    val newSubmittedData = "$namaTugas, $deskripsiMasalah, $prioritasTugas, $userOutcomes, $leadingIndicator, $manfaatProject, $modelAi, $statusTugas, $analisisMasalah, $tanggalMulai, $tanggalbataswaktu, $TanggalDibuat, $tanggalDiperbarui, $NamaProyek, $InformasiTugas, $IdProyek, $PenanggungJawab, $InformasiProyek,  $TimPelaksana, $DetailAnalisis,  $SumberData, $TujuanAnalisis, $MetodeAnalisis, $AlatAnalisis, $CatatanTambahan, "
    onUpdateSubmittedData(newSubmittedData)

    // Menampilkan informasi yang dikirimkan
    if (currentSubmittedData.isNotBlank()) {
        Text("Data yang Dikirim: $currentSubmittedData", color = Color.White)
        Text("Data yang terakhir dikirim: $currentSubmittedData", color = Color.White)
    }
}

@Composable
fun StartScreen(navController: NavController) {
    Column(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Button(onClick = { navController.navigate("formulir") }) { // "formulir" adalah rute ke layar formulir Anda
            Text("Start")
        }
        Spacer(modifier = Modifier.height(16.dp)) // Tambahkan sedikit ruang antara tombol

        Button(onClick = { navController.navigate("tugas") }) { // Navigasi ke layar "tugas"
            Text("Tugas")

            Button(onClick = { navController.popBackStack() }) { // Tombol untuk kembali
                Text("Kembali")
            }
        }
    }
}















