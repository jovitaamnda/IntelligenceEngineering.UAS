package com.example.myapplication

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.DrawerState
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationDrawerItemDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.navigation.NavController
import kotlinx.coroutines.CoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import kotlinx.coroutines.launch


@Composable
fun isRouteSelected(navController: NavHostController, route: String): Boolean {
    return navController.currentBackStackEntry?.destination?.route == route

    @Composable
    fun DrawerContent(navController: NavHostController, drawerState: DrawerState, scope: CoroutineScope) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp)
        ) {
            // Item untuk "mainscreen"
            NavigationDrawerItem(
                label = { Text("Mainscreen") },selected = currentRoute(navController) == "mainscreen",
                onClick = {
                    scope.launch { drawerState.close() }
                    navController.navigate("mainscreen")
                },
                modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
            )

            // Item yang ada untuk "dashboard", "tugas", "aktivitas"

            // Item untuk rute "pekerjaan" yang diperbarui
            NavigationDrawerItem(
                label = { Text("Pekerjaan Lain") },
                selected = currentRoute(navController) == "pekerjaanlain",
                onClick = {
                    scope.launch { drawerState.close() }
                    navController.navigate("pekerjaanlain")
                },
                modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
            )
        }
    }

    // Fungsi currentRoute
    @Composable
    fun currentRoute(navController: NavHostController): String? {
        return navController.currentBackStackEntry?.destination?.route
    }}

