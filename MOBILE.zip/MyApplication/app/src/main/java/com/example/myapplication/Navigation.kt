package com.example.myapplication

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.myapplication.DashboardScreen // Impor DashboardScreen
import com.example.myapplication.TugasScreen // Impor TugasScreen
import com.example.myapplication.AktivitasScreen // Impor AktivitasScreen
import androidx.navigation.NavController
import androidx.navigation.NavHostController
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.rememberDrawerState
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.material3.DrawerValue
import androidx.compose.material3.ModalNavigationDrawer
import androidx.compose.material3.DrawerState
import androidx.compose.material3.NavigationDrawerItem
import androidx.compose.material3.NavigationDrawerItemDefaults
import androidx.compose.material3.Text
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.CoroutineScope
import android.net.Uri
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.material3.MaterialTheme
import androidx.compose.ui.platform.LocalContext
import kotlinx.coroutines.launch
import androidx.activity.ComponentActivity
import androidx.compose.runtime.MutableState


    @Composable
    fun Navigation(navController: NavHostController,
                   savedData: MutableState<String>, // savedData diterima di sini
                   uploadedData: MutableState<String>) {
        NavHost(navController = navController, startDestination = "mainscreen") {
            composable("mainscreen") {
                Mainscreen(navController, onSubmitData = { newText ->
                    savedData.value = newText
                })
            }
            composable("dashboard") { DashboardScreen() }
            composable("tugas/{fileUri}") { backStackEntry ->
                val fileUri = backStackEntry.arguments?.getString("fileUri")
                TugasScreenContent(fileUri)

            }
            composable("aktivitas") { AktivitasScreen() }
            composable("pekerjaan") {
                Mainscreen(navController, onSubmitData =  { newText ->
                    savedData.value = newText
                })
            }
            // Rute lain di sini...
        }
    }

    // DrawerContent.kt
    @Composable
    fun currentRoute(navController: NavHostController): String? {
        return navController.currentBackStackEntry?.destination?.route
    }

@Composable
fun DrawerContent(
    navController: NavHostController,
    drawerState: DrawerState,
    scope: CoroutineScope
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        NavigationDrawerItem(
            label = { Text("Dashboard") },
            selected = false,
            onClick = {
                scope.launch { drawerState.close() }
                navController.navigate("dashboard")
            },
            modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
        )
        NavigationDrawerItem(
            label = { Text("Tugas") },
            selected = false,
            onClick = {
                scope.launch { drawerState.close() }
                navController.navigate("tugas") // Hanya navigasikan ke rute, penanganan file di Mainscreen
            },
            modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
        )
        NavigationDrawerItem(
            label = { Text("Aktivitas") },
            selected = false,
            onClick = {
                scope.launch { drawerState.close() }
                navController.navigate("aktivitas")
            },
            modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding)
        )
        NavigationDrawerItem(
            label = { Text("Pekerjaan") },
            selected = false,
            onClick = {
                scope.launch { drawerState.close() }
                navController.navigate("pekerjaan")
            },
            modifier = Modifier.padding(NavigationDrawerItemDefaults.ItemPadding))

        }
    }
            @Composable
            fun TaskScreen(savedData: String, uploadedData: String) {
                    Column(Modifier.padding(16.dp)) {
                        Text("Data yang Disimpan:", style = MaterialTheme.typography.headlineSmall)
                        Text(savedData, style = MaterialTheme.typography.bodyMedium)
                        Spacer(modifier = Modifier.height(16.dp))
                    }

                        Text("Data yang Diunggah:", style = MaterialTheme.typography.headlineSmall)
                        Text(uploadedData, style = MaterialTheme.typography.bodyMedium)



                        // Hanya tampilkan "Data yang Disimpan" jika savedData tidak kosong
                        if (savedData.isNotBlank()) {
                            Text(
                                "Data yang Disimpan:",
                                style = MaterialTheme.typography.headlineSmall
                            )
                            Text(savedData, style = MaterialTheme.typography.bodyMedium)
                            Spacer(modifier = Modifier.height(16.dp))
                        }
                        // Hanya tampilkan "Data yang Diunggah" jika uploadedData tidak kosong
                        if (uploadedData.isNotBlank()) {
                            Text(
                                "Data yang Diunggah:",
                                style = MaterialTheme.typography.headlineSmall
                            )
                            Text(uploadedData, style = MaterialTheme.typography.bodyMedium)
                        }
                        // Anda dapat menambahkan pesan di sini jika kedua data kosong
                        if (savedData.isBlank() && uploadedData.isBlank()) {
                            Text(
                                "Belum ada data yang tersedia.",
                                style = MaterialTheme.typography.bodyMedium
                            )


                            }

                        }

                    fun getSavedData(): String {
                        // Logika untuk mengambil data yang disimpan
                        return "Data yang disimpan di sini"
                    }

                    fun getUploadedData(): String {
                        // Logika untuk mengambil data yang diunggah
                        return "Data yang diunggah di sini"
                    }







