package com.example.myapplication

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.example.myapplication.ui.theme.MyApplicationTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.Button
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.CenterAlignedTopAppBar
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.draw.shadow
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.ui.graphics.Color
import androidx.compose.material3.Divider
import androidx.compose.foundation.background
import androidx.compose.ui.Alignment
import androidx.compose.foundation.Image
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.layout.ContentScale
import androidx.compose.material3.*
import androidx.compose.material.icons.filled.Menu
import androidx.navigation.compose.rememberNavController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.compose.material3.rememberDrawerState
import kotlinx.coroutines.launch
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.LaunchedEffect
import androidx.navigation.NavHostController
import androidx.compose.ui.text.TextStyle
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import org.threeten.bp.LocalDate
import java.util.Calendar
import java.text.SimpleDateFormat
import java.util.Locale
import androidx.compose.material3.DatePickerDialog
import androidx.compose.material3.DatePicker
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberDatePickerState
import androidx.compose.foundation.border
import java.util.Date


@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun Mainscreen(navController: NavController, onSubmitData: (String) -> Unit) {
    var InformasiTugas by remember { mutableStateOf("") }
    var NamaTugas by remember { mutableStateOf("") }
    var AnalisisMasalah by remember { mutableStateOf("") }
    var DeskripsiMasalah by remember { mutableStateOf("") }
    var PrioritasTugas by remember { mutableStateOf("") }
    var userOutcomes by remember { mutableStateOf("") }
    var Leadingindicator by remember { mutableStateOf("") }
    var ManfaatProjectbagiorganisasi by remember { mutableStateOf("") }
    var ModelAi by remember { mutableStateOf("") }
    var submittedData by remember { mutableStateOf("") }
    var selectedFileUri by remember { mutableStateOf<Uri?>(null) }
    var showRawDataView by remember { mutableStateOf(false) }
    var rawDataForm by remember { mutableStateOf("") }
    var rawDataFile by remember { mutableStateOf("") }
    val statusOptions = listOf("Diterima", "Sedang Diproses", "Selesai", "Update")
    var statusTugas by remember { mutableStateOf("Diterima") } // Status awal
    var expanded by remember { mutableStateOf(false) }
    var selectedStatusText by remember { mutableStateOf(statusOptions[0]) }
    var myText by remember { mutableStateOf("") }
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val scope = rememberCoroutineScope()
    val scrollState = rememberScrollState()
    val datePickerStateBatasWaktu = rememberDatePickerState()
    val datePickerStateMulai = rememberDatePickerState()
    val currentDate = Calendar.getInstance().time
    val dateFormat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
    val formattedDate = dateFormat.format(currentDate)
    val selectedMillis = datePickerStateMulai.selectedDateMillis
    val epochDay = if (selectedMillis != null) selectedMillis / 86400000 else 0L
    var showDatePicker by remember { mutableStateOf(false) }
    val datePickerState = rememberDatePickerState()
    var tanggalMulai by remember {
        mutableStateOf(
            SimpleDateFormat(
                "dd/MM/yyyy",
                Locale.getDefault()
            ).format(Calendar.getInstance().time)
        )
    }
    var tanggalBatasWaktu by remember {
        mutableStateOf(
            SimpleDateFormat(
                "dd/MM/yyyy",
                Locale.getDefault()
            ).format(Calendar.getInstance().time)
        )
    }
    val tanggalDibuat = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(Date())
    var showDatePickerMulai by remember { mutableStateOf(false) }
    var showDatePickerBatasWaktu by remember { mutableStateOf(false) }
    val tanggalDiperbarui =
        SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.getDefault()).format(Date())
    var NamaProyek by remember { mutableStateOf("") }
    var IdProyek by remember { mutableStateOf("") }
    var InformasiProyek by remember { mutableStateOf("") }
    var PenanggungJawab by remember { mutableStateOf("") }
    var TimPelaksana by remember { mutableStateOf("") }
    var SumberData by remember { mutableStateOf("") }
    var TujuanAnalisis by remember { mutableStateOf("") }
    var MetodeAnalisis by remember { mutableStateOf("") }
    var AlatAnalisis by remember { mutableStateOf("") }
    var CatatanTambahan by remember { mutableStateOf("") }
    var DetailAnalisis by remember { mutableStateOf("") }
    var isNamaTugasValid by remember { mutableStateOf(true) }
    var isAnalisisMasalahValid by remember { mutableStateOf(true) }
    var isDeskripsiMasalahValid by remember { mutableStateOf(true) }
    val launcher =

        rememberLauncherForActivityResult(contract = ActivityResultContracts.GetContent()) { uri: Uri? ->
            selectedFileUri = uri
        }

    LaunchedEffect(Unit) {
        drawerState.open()
    }

    Scaffold(
        topBar = {

            CenterAlignedTopAppBar(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.primary),

                title = {
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .padding(8.dp)
                            .background(Color.Yellow),
                        contentAlignment = Alignment.Center

                    ) {
                        Text(
                            text = "Inteligence engineering",
                            style = MaterialTheme.typography.headlineMedium.copy
                                (color = Color.Black),
                            modifier = Modifier.shadow(
                                elevation = 4.dp, // Sesuaikan elevasi bayangan
                                shape = RoundedCornerShape(8.dp) // Sesuaikan bentuk bayangan (opsional)
                            )

                        )
                    }
                },
                navigationIcon = { // Tambahkan ikon navigasi di sini
                    IconButton(onClick = { scope.launch { drawerState.open() } }) {
                        Icon(Icons.Filled.Menu, contentDescription = "Buka Menu")
                    }
                }
            )
        }
    ) { padding -> // Ini menambahkan padding konten di bawah TopAppBar

        Image(
            painter = painterResource(id = R.drawable.latarbelakang), // Ganti your_image_name dengan nama gambar Anda
            contentDescription = "Background Image",
            modifier = Modifier.fillMaxSize(),
            contentScale = ContentScale.Crop // Atau ContentScale.FillBounds/ContentScale.Fit sesuai kebutuhan Anda
        )


        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(padding)
                .verticalScroll(scrollState)
        ) {

            Divider(
                color = Color.Blue, // Ganti dengan warna yang Anda inginkan
                thickness = 1.dp // Sesuaikan ketebalan sesuai kebutuhan

            )
            Spacer(modifier = Modifier.height(15.dp))
            Text("Informasi Tugas: $InformasiTugas", color = Color.Yellow)
            Spacer(modifier = Modifier.height(5.dp))

            OutlinedTextField(
                value = NamaTugas,
                onValueChange = {
                    NamaTugas = it
                    isNamaTugasValid = it.isNotBlank()
                },
                label = { Text("Nama Tugas", color = Color.White) },
                textStyle = TextStyle(color = Color.White),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(
                        width = 1.dp,
                        color = if (isNamaTugasValid) Color.White else Color.Red, // Ubah warna garis tepi berdasarkan validasi
                        shape = RoundedCornerShape(4.dp)
                    ),
                isError = !isNamaTugasValid // Tampilkan status kesalahan jika tidak valid
            )
            if (!isNamaTugasValid) {
                Text("Nama Tugas wajib diisi", color = Color.Red)
            }


            Column(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = AnalisisMasalah,
                    onValueChange = { AnalisisMasalah = it },
                    label = { Text("Analisis Masalah", color = Color.White) },
                    textStyle = TextStyle(color = Color.White),
                    modifier = Modifier.fillMaxWidth()
                        .fillMaxWidth()
                        .border(
                            width = 1.dp,
                            color = if (isNamaTugasValid) Color.White else Color.Red, // Ubah warna garis tepi berdasarkan validasi
                            shape = RoundedCornerShape(4.dp)
                        ),
                    isError = !isAnalisisMasalahValid // Tampilkan status kesalahan jika tidak valid
                )
                if (!isNamaTugasValid) {
                    Text("Analisis Tugas wajib diisi", color = Color.Red)
                }
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = DeskripsiMasalah,
                    onValueChange = { DeskripsiMasalah = it },
                    label = { Text("Deskripsi Masalah", color = Color.White) },
                    textStyle = TextStyle(color = Color.White),
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = PrioritasTugas,
                    onValueChange = { PrioritasTugas = it },
                    label = { Text("Prioritas Tugas", color = Color.White) },
                    textStyle = TextStyle(color = Color.White),
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = userOutcomes,
                    onValueChange = { userOutcomes = it },
                    label = { Text("user Outcomes", color = Color.White) },
                    textStyle = TextStyle(color = Color.White),
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = Leadingindicator,
                    onValueChange = { Leadingindicator = it },
                    label = { Text("Leading Indicator", color = Color.White) },
                    textStyle = TextStyle(color = Color.White),
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = ManfaatProjectbagiorganisasi,
                    onValueChange = { ManfaatProjectbagiorganisasi = it },
                    label = { Text("Manfaat Project bagi organisasi", color = Color.White) },
                    textStyle = TextStyle(color = Color.White),
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = ModelAi,
                    onValueChange = { ModelAi = it },
                    label = { Text("Model AI", color = Color.White) },
                    textStyle = TextStyle(color = Color.White),
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = tanggalMulai,
                    onValueChange = { }, // Tidak perlu mengubah nilai di sini, karena akan diubah oleh DatePickerDialog
                    label = { Text("Tanggal Mulai", color = Color.White) },
                    textStyle = TextStyle(color = Color.White),
                    modifier = Modifier.fillMaxWidth(),
                    readOnly = true,
                    trailingIcon = {
                        IconButton(onClick = { showDatePicker = true }) {
                            Icon(Icons.Filled.ArrowDropDown, contentDescription = null)
                        }
                    }
                )
                if (showDatePicker) {
                    DatePickerDialog(
                        onDismissRequest = { showDatePicker = false },
                        confirmButton = {
                            Button(onClick = {
                                showDatePicker = false
                                val selectedDateMillis = datePickerState.selectedDateMillis
                                if (selectedDateMillis != null) {
                                    tanggalMulai =
                                        SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(
                                            Date(selectedDateMillis)
                                        )
                                }
                            }) {
                                Text("OK")
                            }
                        },
                        dismissButton = {
                            TextButton(onClick = { showDatePicker = false }) {
                                Text("Batal")
                            }
                        }
                    ) {
                        Column {
                            DatePicker(state = datePickerState)
                        }
                    }
                }

                // Batas Waktu
                OutlinedTextField(
                    value = tanggalBatasWaktu,
                    onValueChange = { },
                    label = { Text("Batas Waktu", color = Color.White) },
                    textStyle = TextStyle(color = Color.White),
                    modifier = Modifier.fillMaxWidth(),
                    readOnly = true,
                    trailingIcon = {
                        IconButton(onClick = { showDatePickerBatasWaktu = true }) {
                            Icon(Icons.Filled.ArrowDropDown, contentDescription = null)
                        }
                    }
                )
                if (showDatePickerBatasWaktu) {
                    DatePickerDialog(
                        onDismissRequest = { showDatePickerBatasWaktu = false },
                        confirmButton = {
                            Button(onClick = {
                                showDatePickerBatasWaktu = false
                                val selectedDateMillis =
                                    datePickerStateBatasWaktu.selectedDateMillis
                                if (selectedDateMillis != null) {
                                    tanggalBatasWaktu =
                                        SimpleDateFormat("dd/MM/yyyy", Locale.getDefault()).format(
                                            Date
                                                (selectedDateMillis)
                                        )
                                }
                            }) {
                                Text("OK")
                            }
                        },
                        dismissButton = {
                            TextButton(onClick = { showDatePickerBatasWaktu = false }) {
                                Text("Batal")
                            }
                        }
                    ) {
                        Column {
                            DatePicker(state = datePickerStateBatasWaktu)
                        }
                    }
                }

                // Tanggal Dibuat
                Text("Tanggal Dibuat: $tanggalDibuat", color = Color.White)

                // Tanggal Dibuat
                Text("Tanggal Diperbarui: $tanggalDibuat", color = Color.White)

                Spacer(modifier = Modifier.height(8.dp))
                Box {
                    OutlinedTextField(
                        value = statusTugas,
                        onValueChange = { }, // Tidak perlu mengubah nilai di sini, karena akan diubah oleh DropdownMenu
                        label = { Text("Status Tugas", color = Color.White) },
                        textStyle = TextStyle(color = Color.White),
                        trailingIcon = {
                            IconButton(onClick = { expanded = !expanded }) {
                                Icon(
                                    imageVector = Icons.Filled.ArrowDropDown,
                                    contentDescription = "Dropdown pilihan"
                                )

                            }
                        },
                        modifier = Modifier.fillMaxWidth(),
                        readOnly = true
                    )
                    DropdownMenu(
                        expanded = expanded,
                        onDismissRequest = { expanded = false },
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        statusOptions.forEach { selectionOption ->
                            DropdownMenuItem(
                                text = { Text("pilihan") },
                                onClick = {
                                    statusTugas = selectionOption
                                    expanded = false
                                })
                            Text(
                                text =
                                selectionOption
                            )

                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(25.dp))
            Text("Informasi Proyek: $InformasiProyek", color = Color.Yellow)

            OutlinedTextField(
                value = NamaProyek,
                onValueChange = { NamaProyek = it },
                label = { Text("Nama Proyek", color = Color.White) },
                textStyle = TextStyle(color = Color.White),
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = IdProyek,
                onValueChange = { IdProyek = it },
                label = { Text("Id Proyek", color = Color.White) },
                textStyle = TextStyle(color = Color.White),
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = PenanggungJawab,
                onValueChange = { PenanggungJawab = it },
                label = { Text("Penanggung Jawab", color = Color.White) },
                textStyle = TextStyle(color = Color.White),
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = TimPelaksana,
                onValueChange = { TimPelaksana = it },
                label = { Text("Tim Pelaksana", color = Color.White) },
                textStyle = TextStyle(color = Color.White),
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(modifier = Modifier.height(25.dp))
            Text("Detail Analisis: $DetailAnalisis", color = Color.Yellow)

            OutlinedTextField(
                value = SumberData,
                onValueChange = { SumberData = it },
                label = { Text("Sumber Data", color = Color.White) },
                textStyle = TextStyle(color = Color.White),
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = TujuanAnalisis,
                onValueChange = { TujuanAnalisis = it },
                label = { Text("Tujuan Analisis", color = Color.White) },
                textStyle = TextStyle(color = Color.White),
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = AlatAnalisis,
                onValueChange = { AlatAnalisis = it },
                label = { Text("Alat Analisis", color = Color.White) },
                textStyle = TextStyle(color = Color.White),
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = MetodeAnalisis,
                onValueChange = { MetodeAnalisis = it },
                label = { Text("Metode Analisis", color = Color.White) },
                textStyle = TextStyle(color = Color.White),
                modifier = Modifier.fillMaxWidth()
            )
            OutlinedTextField(
                value = CatatanTambahan,
                onValueChange = { CatatanTambahan = it },
                label = { Text("Catatan Tambahan", color = Color.White) },
                textStyle = TextStyle(color = Color.White),
                modifier = Modifier.fillMaxWidth()
            )

            Row(modifier = Modifier.fillMaxWidth()) {
                Button(
                    onClick = {
                        submittedData =
                            "$NamaTugas, $DeskripsiMasalah, $PrioritasTugas, $userOutcomes, $Leadingindicator,  $ManfaatProjectbagiorganisasi,  $ModelAi, $statusTugas, $AnalisisMasalah, $tanggalMulai, $NamaProyek, $InformasiTugas, $IdProyek, $PenanggungJawab, $TimPelaksana,  $DetailAnalisis, $SumberData, $TujuanAnalisis, $MetodeAnalisis, $AlatAnalisis, $CatatanTambahan, "
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Text("Save")
                }

                Spacer(modifier = Modifier.width(8.dp)) // Tetap di dalam Row, gunakan width

                    Button(
                        onClick = { launcher.launch("image/*, application/pdf, application/msword ") },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Unggah File")
                    }
                } // Akhir Row
            }
        }
    }


